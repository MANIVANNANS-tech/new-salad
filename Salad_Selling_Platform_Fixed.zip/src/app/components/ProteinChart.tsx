import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
  Legend,
} from "recharts";
import type { Product } from "../data/products";

interface ProteinBarChartProps {
  products: Product[];
  audience: "children" | "adult";
}

const COLORS_CHILDREN = [
  "#f472b6", "#fb923c", "#facc15", "#4ade80", "#60a5fa", "#a78bfa",
];
const COLORS_ADULT = [
  "#3b82f6", "#06b6d4", "#8b5cf6", "#f59e0b", "#ef4444", "#10b981",
];

const CustomTooltip = ({
  active, payload, label, audience,
}: {
  active?: boolean;
  payload?: { value: number }[];
  label?: string;
  audience: "children" | "adult";
}) => {
  if (active && payload && payload.length) {
    const color = audience === "children" ? "#ec4899" : "#2563eb";
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 px-4 py-3">
        <p className="text-gray-700 mb-1" style={{ fontWeight: 600, fontSize: "0.82rem" }}>
          {label}
        </p>
        <p style={{ color, fontWeight: 700, fontSize: "0.9rem" }}>
          {payload[0].value}g protein
        </p>
      </div>
    );
  }
  return null;
};

export function ProteinBarChart({ products, audience }: ProteinBarChartProps) {
  const COLORS = audience === "children" ? COLORS_CHILDREN : COLORS_ADULT;
  const barColor = audience === "children" ? "#ec4899" : "#2563eb";
  const accentColor = audience === "children" ? "#f9a8d4" : "#93c5fd";

  const data = products.map((p) => ({
    name: p.name.length > 16 ? p.name.slice(0, 14) + "…" : p.name,
    fullName: p.name,
    protein: p.protein,
  }));

  // Daily recommended protein
  const recommended = audience === "children" ? 20 : 50;

  return (
    <div className="w-full">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart
          data={data}
          margin={{ top: 10, right: 10, left: -10, bottom: 5 }}
          barSize={32}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis
            dataKey="name"
            tick={{ fontSize: 11, fill: "#6b7280" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: "#6b7280" }}
            axisLine={false}
            tickLine={false}
            unit="g"
            domain={[0, audience === "children" ? 15 : 50]}
          />
          <Tooltip
            content={<CustomTooltip audience={audience} label="" />}
            cursor={{ fill: "rgba(0,0,0,0.04)", radius: 8 }}
          />
          <Bar dataKey="protein" radius={[6, 6, 0, 0]}>
            {data.map((_, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
                opacity={0.9}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>

      {/* Legend — daily target indicator */}
      <div className="flex items-center justify-center gap-4 mt-1">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-full" style={{ background: barColor }} />
          <span className="text-gray-500" style={{ fontSize: "0.75rem" }}>Protein per serving (g)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-full bg-gray-200" />
          <span className="text-gray-500" style={{ fontSize: "0.75rem" }}>
            Daily target: ~{recommended}g
          </span>
        </div>
      </div>
    </div>
  );
}

interface NutritionRadarProps {
  product: Product;
  audience: "children" | "adult";
}

export function NutritionRadar({ product, audience }: NutritionRadarProps) {
  const color = audience === "children" ? "#ec4899" : "#2563eb";
  const fillColor = audience === "children" ? "#fce7f3" : "#dbeafe";

  // Normalize to 0–10 scale
  const maxProtein = audience === "children" ? 12 : 45;
  const data = [
    { subject: "Protein", A: Math.round((product.protein / maxProtein) * 10) },
    { subject: "Fiber", A: product.fiber },
    { subject: "Vitamins", A: product.vitamins },
    { subject: "Carbs", A: Math.min(10, Math.round(product.carbs / 7)) },
    { subject: "Calories", A: Math.min(10, Math.round(product.calories / 60)) },
  ];

  return (
    <ResponsiveContainer width="100%" height={180}>
      <RadarChart data={data}>
        <PolarGrid stroke="#e5e7eb" />
        <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11, fill: "#6b7280" }} />
        <Radar
          name={product.name}
          dataKey="A"
          stroke={color}
          fill={fillColor}
          fillOpacity={0.7}
        />
      </RadarChart>
    </ResponsiveContainer>
  );
}

interface ProteinComparisonProps {
  products: Product[];
  audience: "children" | "adult";
}

export function ProteinComparison({ products, audience }: ProteinComparisonProps) {
  const maxProtein = Math.max(...products.map((p) => p.protein));
  const barColor = audience === "children" ? "#ec4899" : "#2563eb";
  const bgColor = audience === "children" ? "#fce7f3" : "#dbeafe";

  return (
    <div className="space-y-3">
      {products.map((p) => (
        <div key={p.id} className="flex items-center gap-3">
          <span
            className="text-gray-600 truncate shrink-0"
            style={{ fontSize: "0.78rem", width: 130, textAlign: "right" }}
          >
            {p.name.length > 18 ? p.name.slice(0, 16) + "…" : p.name}
          </span>
          <div className="flex-1 h-6 rounded-full overflow-hidden" style={{ background: bgColor }}>
            <div
              className="h-full rounded-full flex items-center px-2 transition-all duration-700"
              style={{
                width: `${(p.protein / maxProtein) * 100}%`,
                minWidth: 36,
                background: barColor,
              }}
            >
              <span className="text-white" style={{ fontSize: "0.7rem", fontWeight: 700 }}>
                {p.protein}g
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
