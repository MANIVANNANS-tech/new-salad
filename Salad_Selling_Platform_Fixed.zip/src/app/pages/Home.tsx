import { Link } from "react-router";
import { ArrowRight, Leaf, Clock, Award, Truck, Star, ChevronRight } from "lucide-react";
import { motion } from "motion/react";
import { products } from "../data/products";
import { ProductCard } from "../components/ProductCard";

const features = [
  {
    icon: Leaf,
    title: "100% Organic",
    desc: "All ingredients sourced from certified organic farms.",
    color: "bg-green-100 text-green-600",
  },
  {
    icon: Clock,
    title: "Made Fresh Daily",
    desc: "Prepared every morning for peak freshness and taste.",
    color: "bg-orange-100 text-orange-600",
  },
  {
    icon: Truck,
    title: "Fast Delivery",
    desc: "Delivered to your door in under 45 minutes.",
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: Award,
    title: "Chef-Crafted",
    desc: "Recipes designed by award-winning nutritionist chefs.",
    color: "bg-purple-100 text-purple-600",
  },
];

const testimonials = [
  {
    name: "Sarah M.",
    text: "The Rainbow Fruit Bowl is absolutely divine! So fresh and beautifully presented. My new morning staple.",
    rating: 5,
    avatar: "S",
  },
  {
    name: "James K.",
    text: "Best salads in the city! The Avocado Power Bowl keeps me full all day and tastes incredible.",
    rating: 5,
    avatar: "J",
  },
  {
    name: "Priya L.",
    text: "Quick delivery, super fresh, and the portions are generous. FreshBowl has completely changed my lunch game.",
    rating: 5,
    avatar: "P",
  },
];

export default function Home() {
  const featured = products.filter((p) => p.badge && p.audience === "all").slice(0, 4);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-50 via-white to-orange-50 py-16 md:py-24">
        <div
          className="absolute top-0 right-0 w-1/2 h-full opacity-10"
          style={{
            backgroundImage:
              "radial-gradient(circle at 70% 40%, #22c55e 0%, transparent 60%)",
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-1.5 bg-green-100 text-green-700 px-3 py-1 rounded-full mb-4" style={{ fontSize: "0.8rem", fontWeight: 600 }}>
              <Leaf className="w-3 h-3" /> 100% Organic & Fresh
            </span>
            <h1 className="text-gray-900 mb-5" style={{ fontSize: "clamp(2rem, 5vw, 3.25rem)", fontWeight: 800, lineHeight: 1.15 }}>
              Eat Fresh,{" "}
              <span className="text-green-500">Feel Amazing</span>
              <br />Every Single Day
            </h1>
            <p className="text-gray-500 mb-8 max-w-md" style={{ fontSize: "1.05rem", lineHeight: 1.7 }}>
              Handcrafted fruit and vegetable salads made fresh daily from organic produce. Nutritious, delicious, and delivered to your door.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors shadow-sm"
                style={{ fontWeight: 600 }}
              >
                Explore Menu <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/about"
                className="inline-flex items-center gap-2 px-6 py-3 border border-gray-200 text-gray-700 rounded-full hover:border-green-300 hover:text-green-700 transition-colors"
                style={{ fontWeight: 500 }}
              >
                Our Story
              </Link>
            </div>
            {/* Stats */}
            <div className="flex gap-8 mt-10">
              {[
                { value: "50+", label: "Fresh Salads" },
                { value: "10k+", label: "Happy Customers" },
                { value: "4.9★", label: "Avg Rating" },
              ].map((stat) => (
                <div key={stat.label}>
                  <p className="text-gray-900" style={{ fontSize: "1.4rem", fontWeight: 700 }}>
                    {stat.value}
                  </p>
                  <p className="text-gray-400" style={{ fontSize: "0.8rem" }}>
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative hidden md:block"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-square max-w-lg mx-auto">
              <img
                src="https://images.unsplash.com/photo-1642635055753-3eec6c0b2a6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGZydWl0JTIwc2FsYWQlMjBib3dsJTIwY29sb3JmdWx8ZW58MXx8fHwxNzczODE0NDcwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Fresh Fruit Salad"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating cards */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-lg px-4 py-3 flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Leaf className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-gray-800" style={{ fontSize: "0.85rem", fontWeight: 700 }}>100% Organic</p>
                <p className="text-gray-400" style={{ fontSize: "0.72rem" }}>Certified farms only</p>
              </div>
            </motion.div>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut" }}
              className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-lg px-4 py-3 flex items-center gap-2"
            >
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-gray-800" style={{ fontWeight: 700, fontSize: "0.9rem" }}>4.9 / 5.0</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-14 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className={`w-12 h-12 rounded-2xl ${feature.color} flex items-center justify-center mx-auto mb-3`}>
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-gray-800 mb-1" style={{ fontSize: "0.9rem", fontWeight: 600 }}>
                  {feature.title}
                </h3>
                <p className="text-gray-400" style={{ fontSize: "0.78rem", lineHeight: 1.5 }}>
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-14 bg-gray-50/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-green-600 mb-1 block" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
                🌿 Top Picks
              </span>
              <h2 className="text-gray-900" style={{ fontSize: "clamp(1.4rem, 3vw, 1.9rem)", fontWeight: 700 }}>
                Fan Favorites
              </h2>
            </div>
            <Link
              to="/menu"
              className="flex items-center gap-1 text-green-600 hover:text-green-700 transition-colors"
              style={{ fontSize: "0.875rem", fontWeight: 600 }}
            >
              View all <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Children & Adult Category Cards */}
      <section className="py-14 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <span className="text-green-600 mb-1 block" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
              🎯 Shop by Age Group
            </span>
            <h2 className="text-gray-900" style={{ fontSize: "clamp(1.4rem, 3vw, 1.9rem)", fontWeight: 700 }}>
              Salads for Every Stage of Life
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Children's Card */}
            <motion.div
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-pink-100 via-yellow-50 to-purple-100 p-8 border border-pink-100"
            >
              <div className="absolute top-0 right-0 text-9xl opacity-10 pointer-events-none select-none" style={{ lineHeight: 1 }}>🌈</div>
              <span className="inline-block bg-pink-500 text-white px-3 py-1 rounded-full mb-3" style={{ fontSize: "0.75rem", fontWeight: 600 }}>
                👧 Children's Menu
              </span>
              <h3 className="text-gray-900 mb-2" style={{ fontSize: "1.4rem", fontWeight: 800 }}>
                Fun & Nutritious
              </h3>
              <p className="text-gray-600 mb-4" style={{ fontSize: "0.875rem", lineHeight: 1.7 }}>
                Packed with colorful veggies, fruits & sprouts that kids love. Gentle ingredients, big nutrition.
              </p>
              <div className="flex flex-wrap gap-2 mb-5">
                {["🥦 Veggies", "🍓 Fruits", "🌱 Sprouts"].map((tag) => (
                  <span key={tag} className="bg-white/80 text-pink-700 px-3 py-1 rounded-full" style={{ fontSize: "0.78rem", fontWeight: 600 }}>
                    {tag}
                  </span>
                ))}
              </div>
              <Link
                to="/menu"
                onClick={() => {}}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-full transition-colors"
                style={{ fontWeight: 600, fontSize: "0.875rem" }}
              >
                Explore Kids' Menu <ArrowRight className="w-4 h-4" />
              </Link>
              <div className="mt-5 grid grid-cols-3 gap-3">
                {products.filter((p) => p.audience === "children").slice(0, 3).map((p) => (
                  <div key={p.id} className="rounded-xl overflow-hidden aspect-square">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Adult Card */}
            <motion.div
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-100 via-indigo-50 to-cyan-100 p-8 border border-blue-100"
            >
              <div className="absolute top-0 right-0 text-9xl opacity-10 pointer-events-none select-none" style={{ lineHeight: 1 }}>💪</div>
              <span className="inline-block bg-blue-600 text-white px-3 py-1 rounded-full mb-3" style={{ fontSize: "0.75rem", fontWeight: 600 }}>
                💪 Adult Menu
              </span>
              <h3 className="text-gray-900 mb-2" style={{ fontSize: "1.4rem", fontWeight: 800 }}>
                High Protein & Power
              </h3>
              <p className="text-gray-600 mb-4" style={{ fontSize: "0.875rem", lineHeight: 1.7 }}>
                Performance-driven salads loaded with premium protein, omega-3s and muscle-supporting nutrients.
              </p>
              <div className="flex flex-wrap gap-2 mb-5">
                {["🍗 Chicken", "🐟 Salmon", "🥩 Steak", "🌿 Lentils"].map((tag) => (
                  <span key={tag} className="bg-white/80 text-blue-700 px-3 py-1 rounded-full" style={{ fontSize: "0.78rem", fontWeight: 600 }}>
                    {tag}
                  </span>
                ))}
              </div>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition-colors"
                style={{ fontWeight: 600, fontSize: "0.875rem" }}
              >
                Explore Adult Menu <ArrowRight className="w-4 h-4" />
              </Link>
              <div className="mt-5 grid grid-cols-3 gap-3">
                {products.filter((p) => p.audience === "adult").slice(0, 3).map((p) => (
                  <div key={p.id} className="rounded-xl overflow-hidden aspect-square">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-3xl bg-gradient-to-r from-green-500 to-emerald-600 p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 overflow-hidden relative">
            <div
              className="absolute inset-0 opacity-10"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 80% 50%, white 0%, transparent 60%)",
              }}
            />
            <div className="relative z-10">
              <h2 className="text-white mb-2" style={{ fontSize: "clamp(1.4rem, 3vw, 2rem)", fontWeight: 700 }}>
                Free Delivery on Orders Over $30!
              </h2>
              <p className="text-green-100" style={{ fontSize: "0.95rem" }}>
                Use code <strong>FRESHSTART</strong> for 15% off your first order.
              </p>
            </div>
            <Link
              to="/menu"
              className="relative z-10 inline-flex items-center gap-2 px-6 py-3 bg-white text-green-700 rounded-full hover:bg-green-50 transition-colors shrink-0"
              style={{ fontWeight: 700 }}
            >
              Order Now <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-14 bg-gray-50/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <span className="text-green-600 mb-1 block" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
              💬 Reviews
            </span>
            <h2 className="text-gray-900" style={{ fontSize: "clamp(1.4rem, 3vw, 1.9rem)", fontWeight: 700 }}>
              What Our Customers Say
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100"
              >
                <div className="flex mb-3">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4" style={{ fontSize: "0.875rem", lineHeight: 1.7 }}>
                  "{t.text}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-green-100 flex items-center justify-center text-green-700" style={{ fontWeight: 700 }}>
                    {t.avatar}
                  </div>
                  <span className="text-gray-700" style={{ fontSize: "0.875rem", fontWeight: 600 }}>
                    {t.name}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                <Leaf className="w-4 h-4 text-white" />
              </div>
              <span className="text-white" style={{ fontWeight: 700 }}>FreshBowl</span>
            </div>
            <div className="flex gap-6" style={{ fontSize: "0.85rem" }}>
              {["Privacy Policy", "Terms of Service", "Contact Us"].map((item) => (
                <a key={item} href="#" className="hover:text-white transition-colors">
                  {item}
                </a>
              ))}
            </div>
            <p style={{ fontSize: "0.8rem" }}>© 2026 FreshBowl. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}