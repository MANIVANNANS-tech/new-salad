import { useState, useMemo } from "react";
import { Search, SlidersHorizontal, X, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import {
  products,
  categories,
  audienceCategories,
  childrenSubcategories,
} from "../data/products";
import { ProductCard } from "../components/ProductCard";
import { ProteinBarChart, ProteinComparison } from "../components/ProteinChart";

const sortOptions = [
  { id: "default", label: "Featured" },
  { id: "protein-desc", label: "Highest Protein" },
  { id: "protein-asc", label: "Lowest Protein" },
  { id: "price-asc", label: "Price: Low to High" },
  { id: "price-desc", label: "Price: High to Low" },
  { id: "rating", label: "Highest Rated" },
  { id: "calories", label: "Lowest Calories" },
];

export default function Menu() {
  const [audience, setAudience] = useState("all");
  const [activeCategory, setActiveCategory] = useState("all");
  const [childrenSub, setChildrenSub] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("default");

  const filtered = useMemo(() => {
    let result = [...products];

    // Audience filter
    if (audience === "children") {
      result = result.filter((p) => p.audience === "children");
    } else if (audience === "adult") {
      result = result.filter((p) => p.audience === "adult");
    }

    // Subcategory (for children)
    if (audience === "children" && childrenSub !== "all") {
      result = result.filter((p) => p.subcategory === childrenSub);
    }

    // Type category (for "all" audience)
    if (audience === "all" && activeCategory !== "all") {
      result = result.filter((p) => p.category === activeCategory);
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tags.some((t) => t.includes(q))
      );
    }

    // Sort
    switch (sortBy) {
      case "protein-desc": result.sort((a, b) => b.protein - a.protein); break;
      case "protein-asc": result.sort((a, b) => a.protein - b.protein); break;
      case "price-asc": result.sort((a, b) => a.price - b.price); break;
      case "price-desc": result.sort((a, b) => b.price - a.price); break;
      case "rating": result.sort((a, b) => b.rating - a.rating); break;
      case "calories": result.sort((a, b) => a.calories - b.calories); break;
    }

    return result;
  }, [audience, activeCategory, childrenSub, searchQuery, sortBy]);

  const isChildren = audience === "children";
  const isAdult = audience === "adult";

  return (
    <div className="min-h-screen bg-gray-50/40">
      {/* ── Audience Selector Banner ────────────────────────── */}
      <div
        className={`transition-all duration-500 ${
          isChildren
            ? "bg-gradient-to-r from-pink-50 via-yellow-50 to-purple-50 border-b border-pink-100"
            : isAdult
            ? "bg-gradient-to-r from-blue-50 via-indigo-50 to-cyan-50 border-b border-blue-100"
            : "bg-white border-b border-gray-100"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          {/* Audience Tabs */}
          <div className="flex items-center gap-3 mb-6 flex-wrap">
            {audienceCategories.map((aud) => (
              <button
                key={aud.id}
                onClick={() => {
                  setAudience(aud.id);
                  setActiveCategory("all");
                  setChildrenSub("all");
                }}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full transition-all duration-200 shadow-sm ${
                  audience === aud.id ? aud.active : aud.color
                }`}
                style={{ fontWeight: 600, fontSize: "0.9rem" }}
              >
                <span>{aud.emoji}</span> {aud.label}
              </button>
            ))}
          </div>

          {/* Category heading */}
          <div className="mb-5">
            {isChildren && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <h1 className="text-gray-900 mb-1" style={{ fontSize: "clamp(1.5rem, 4vw, 2rem)", fontWeight: 800 }}>
                  👧 Children's Salad Menu
                </h1>
                <p className="text-gray-500">
                  Fun, fresh, and nutritious — packed with veggies, fruits & sprouts kids actually love!
                </p>
              </motion.div>
            )}
            {isAdult && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <h1 className="text-gray-900 mb-1" style={{ fontSize: "clamp(1.5rem, 4vw, 2rem)", fontWeight: 800 }}>
                  💪 Adult Salad Menu
                </h1>
                <p className="text-gray-500">
                  High-performance salads designed to fuel your body with premium protein and nutrients.
                </p>
              </motion.div>
            )}
            {!isChildren && !isAdult && (
              <div>
                <h1 className="text-gray-900 mb-1" style={{ fontSize: "clamp(1.5rem, 4vw, 2rem)", fontWeight: 800 }}>
                  Our Fresh Menu
                </h1>
                <p className="text-gray-500">
                  {products.length} handcrafted salads made fresh daily
                </p>
              </div>
            )}
          </div>

          {/* Search + Sort */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search salads, ingredients…"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400"
                style={{ fontSize: "0.875rem" }}
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2.5 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 text-gray-700 focus:outline-none focus:ring-2 focus:ring-green-400 cursor-pointer"
              style={{ fontSize: "0.875rem" }}
            >
              {sortOptions.map((opt) => (
                <option key={opt.id} value={opt.id}>{opt.label}</option>
              ))}
            </select>
          </div>

          {/* Sub-filters */}
          {isChildren && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="flex gap-2 mt-4 flex-wrap"
            >
              {childrenSubcategories.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setChildrenSub(sub.id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition-all duration-200 ${
                    childrenSub === sub.id
                      ? "bg-pink-500 text-white shadow-sm"
                      : "bg-white text-pink-600 border border-pink-200 hover:bg-pink-50"
                  }`}
                  style={{ fontSize: "0.85rem", fontWeight: 500 }}
                >
                  {sub.emoji} {sub.label}
                </button>
              ))}
            </motion.div>
          )}

          {!isChildren && !isAdult && (
            <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`shrink-0 px-4 py-2 rounded-full transition-all duration-200 ${
                    activeCategory === cat.id
                      ? "bg-green-500 text-white shadow-sm"
                      : "bg-white text-gray-600 border border-gray-200 hover:bg-gray-50"
                  }`}
                  style={{ fontSize: "0.85rem", fontWeight: 500 }}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Protein Charts Section ───────────────────────────── */}
      <AnimatePresence>
        {(isChildren || isAdult) && (
          <motion.section
            key={audience}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`py-8 ${isChildren ? "bg-pink-50/60" : "bg-blue-50/60"}`}
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid lg:grid-cols-5 gap-6">

                {/* Bar Chart */}
                <div className={`lg:col-span-3 bg-white rounded-2xl shadow-sm p-5 border ${isChildren ? "border-pink-100" : "border-blue-100"}`}>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-gray-800" style={{ fontWeight: 700, fontSize: "1rem" }}>
                        {isChildren ? "🌱 Protein per Kids' Salad" : "💪 Protein per Adult Salad"}
                      </h3>
                      <p className="text-gray-400" style={{ fontSize: "0.75rem" }}>
                        {isChildren
                          ? "Daily protein goal for children: ~20g"
                          : "Daily protein goal for adults: ~50g"}
                      </p>
                    </div>
                    <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs ${isChildren ? "bg-pink-100 text-pink-700" : "bg-blue-100 text-blue-700"}`} style={{ fontWeight: 600 }}>
                      <Info className="w-3 h-3" /> Protein Chart
                    </div>
                  </div>
                  <ProteinBarChart
                    products={filtered.length > 0 ? filtered : products.filter((p) => p.audience === audience)}
                    audience={audience as "children" | "adult"}
                  />
                </div>

                {/* Horizontal bar comparison */}
                <div className={`lg:col-span-2 bg-white rounded-2xl shadow-sm p-5 border ${isChildren ? "border-pink-100" : "border-blue-100"}`}>
                  <h3 className="text-gray-800 mb-4" style={{ fontWeight: 700, fontSize: "1rem" }}>
                    Protein Comparison
                  </h3>
                  <ProteinComparison
                    products={
                      (filtered.length > 0 ? filtered : products.filter((p) => p.audience === audience))
                        .slice(0, 6)
                    }
                    audience={audience as "children" | "adult"}
                  />

                  {/* Nutrition Facts summary */}
                  <div className={`mt-5 p-3 rounded-xl ${isChildren ? "bg-pink-50" : "bg-blue-50"}`}>
                    <p className={`mb-2 ${isChildren ? "text-pink-700" : "text-blue-700"}`} style={{ fontSize: "0.78rem", fontWeight: 700 }}>
                      {isChildren ? "🧒 Kids' Nutrition Guide" : "🏋️ Adult Nutrition Guide"}
                    </p>
                    {isChildren ? (
                      <ul className="text-gray-500 space-y-1" style={{ fontSize: "0.73rem" }}>
                        <li>• Recommended daily protein: 19–34g (ages 4–13)</li>
                        <li>• Rich in vitamins A, C & D for growth</li>
                        <li>• Sprouts boost enzymes & immune health</li>
                        <li>• No artificial colours or flavours added</li>
                      </ul>
                    ) : (
                      <ul className="text-gray-500 space-y-1" style={{ fontSize: "0.73rem" }}>
                        <li>• Recommended daily protein: 46–56g (adults)</li>
                        <li>• Supports muscle repair & metabolism</li>
                        <li>• Rich in omega-3, iron & B-vitamins</li>
                        <li>• Balanced macros for sustained energy</li>
                      </ul>
                    )}
                  </div>
                </div>
              </div>

              {/* Stat pills */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
                {[
                  {
                    label: "Avg Protein",
                    value:
                      filtered.length > 0
                        ? Math.round(filtered.reduce((s, p) => s + p.protein, 0) / filtered.length) + "g"
                        : "—",
                    color: isChildren ? "bg-pink-100 text-pink-700" : "bg-blue-100 text-blue-700",
                  },
                  {
                    label: "Avg Calories",
                    value:
                      filtered.length > 0
                        ? Math.round(filtered.reduce((s, p) => s + p.calories, 0) / filtered.length) + " kcal"
                        : "—",
                    color: "bg-orange-100 text-orange-700",
                  },
                  {
                    label: "Avg Fiber",
                    value:
                      filtered.length > 0
                        ? Math.round(filtered.reduce((s, p) => s + p.fiber, 0) / filtered.length) + "g"
                        : "—",
                    color: "bg-green-100 text-green-700",
                  },
                  {
                    label: "Avg Vitamins",
                    value:
                      filtered.length > 0
                        ? (filtered.reduce((s, p) => s + p.vitamins, 0) / filtered.length).toFixed(1) + "/10"
                        : "—",
                    color: "bg-purple-100 text-purple-700",
                  },
                ].map((stat) => (
                  <div key={stat.label} className={`rounded-xl p-3 text-center ${stat.color}`}>
                    <p style={{ fontSize: "1.1rem", fontWeight: 700 }}>{stat.value}</p>
                    <p style={{ fontSize: "0.72rem" }}>{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* ── Products Grid ────────────────────────────────────── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-500" style={{ fontSize: "0.875rem" }}>
            Showing <strong className="text-gray-700">{filtered.length}</strong>{" "}
            {isChildren ? "children's" : isAdult ? "adult" : ""} salad
            {filtered.length !== 1 ? "s" : ""}
          </p>
          {(searchQuery || (audience === "all" && activeCategory !== "all")) && (
            <button
              onClick={() => { setSearchQuery(""); setActiveCategory("all"); }}
              className="flex items-center gap-1 text-green-600 hover:text-green-700 transition-colors"
              style={{ fontSize: "0.85rem", fontWeight: 600 }}
            >
              <X className="w-3.5 h-3.5" /> Clear filters
            </button>
          )}
        </div>

        <AnimatePresence mode="wait">
          {filtered.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-20"
            >
              <p className="text-gray-400" style={{ fontSize: "1.1rem" }}>
                🥗 No salads found. Try a different search!
              </p>
            </motion.div>
          ) : (
            <motion.div
              key={`${audience}-${activeCategory}-${childrenSub}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5"
            >
              {filtered.map((product, i) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <ProductCard product={product} audience={audience as "all" | "children" | "adult"} />
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
