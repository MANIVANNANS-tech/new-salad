import { useState } from "react";
import { ArrowLeft, CheckCircle2, CreditCard, MapPin, User } from "lucide-react";
import { Link, useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { useCart } from "../context/CartContext";

type Step = "details" | "payment" | "success";

export default function Checkout() {
  const { items, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("details");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    zip: "",
    cardName: "",
    cardNumber: "",
    expiry: "",
    cvv: "",
    notes: "",
  });

  const delivery = totalPrice >= 30 ? 0 : 3.99;
  const total = totalPrice + delivery;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("payment");
  };

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("success");
    clearCart();
  };

  if (items.length === 0 && step !== "success") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 px-4">
        <p className="text-gray-500 mb-4" style={{ fontSize: "1.1rem" }}>Your cart is empty.</p>
        <Link
          to="/menu"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Browse Menu
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">

        <AnimatePresence mode="wait">
          {step === "success" ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-3xl shadow-sm p-10 text-center max-w-lg mx-auto"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-5"
              >
                <CheckCircle2 className="w-10 h-10 text-green-500" />
              </motion.div>
              <h2 className="text-gray-900 mb-2" style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                Order Placed! 🎉
              </h2>
              <p className="text-gray-500 mb-2">
                Thank you for your order! Your fresh salads are being prepared.
              </p>
              <p className="text-green-600 mb-6" style={{ fontWeight: 600 }}>
                Estimated delivery: 35–45 minutes
              </p>
              <div className="bg-green-50 rounded-2xl p-4 mb-6 text-left">
                <p className="text-gray-600" style={{ fontSize: "0.875rem" }}>
                  📧 A confirmation email has been sent to <strong>{form.email || "your email"}</strong>
                </p>
              </div>
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors"
                style={{ fontWeight: 600 }}
              >
                Back to Home
              </Link>
            </motion.div>
          ) : (
            <motion.div key="checkout" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              {/* Back button */}
              <Link
                to="/menu"
                className="inline-flex items-center gap-1.5 text-gray-500 hover:text-green-700 transition-colors mb-6"
                style={{ fontSize: "0.875rem" }}
              >
                <ArrowLeft className="w-4 h-4" /> Back to Menu
              </Link>

              <h1 className="text-gray-900 mb-6" style={{ fontWeight: 700, fontSize: "1.6rem" }}>
                Checkout
              </h1>

              {/* Progress */}
              <div className="flex items-center gap-3 mb-8">
                {[
                  { id: "details", label: "Delivery", icon: MapPin },
                  { id: "payment", label: "Payment", icon: CreditCard },
                ].map((s, i) => (
                  <div key={s.id} className="flex items-center gap-2">
                    <div
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${
                        step === s.id
                          ? "bg-green-500 text-white"
                          : step === "payment" && s.id === "details"
                          ? "bg-green-100 text-green-700"
                          : "bg-gray-100 text-gray-400"
                      }`}
                      style={{ fontSize: "0.82rem", fontWeight: 600 }}
                    >
                      <s.icon className="w-3.5 h-3.5" />
                      {s.label}
                    </div>
                    {i === 0 && <div className="w-8 h-0.5 bg-gray-200" />}
                  </div>
                ))}
              </div>

              <div className="grid lg:grid-cols-3 gap-6">
                {/* Form */}
                <div className="lg:col-span-2">
                  {step === "details" && (
                    <motion.form
                      key="details-form"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      onSubmit={handleDetailsSubmit}
                      className="bg-white rounded-2xl shadow-sm p-6 space-y-4"
                    >
                      <div className="flex items-center gap-2 mb-5">
                        <User className="w-4 h-4 text-green-600" />
                        <h3 className="text-gray-800" style={{ fontWeight: 600 }}>
                          Contact & Delivery
                        </h3>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                            Full Name *
                          </label>
                          <input
                            name="name"
                            required
                            value={form.name}
                            onChange={handleChange}
                            placeholder="Jane Doe"
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                            style={{ fontSize: "0.875rem" }}
                          />
                        </div>
                        <div>
                          <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                            Email *
                          </label>
                          <input
                            name="email"
                            type="email"
                            required
                            value={form.email}
                            onChange={handleChange}
                            placeholder="jane@example.com"
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                            style={{ fontSize: "0.875rem" }}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                          Phone Number *
                        </label>
                        <input
                          name="phone"
                          type="tel"
                          required
                          value={form.phone}
                          onChange={handleChange}
                          placeholder="+1 (555) 000-0000"
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                          style={{ fontSize: "0.875rem" }}
                        />
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                          Delivery Address *
                        </label>
                        <input
                          name="address"
                          required
                          value={form.address}
                          onChange={handleChange}
                          placeholder="123 Green Street, Apt 4B"
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                          style={{ fontSize: "0.875rem" }}
                        />
                      </div>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                            City *
                          </label>
                          <input
                            name="city"
                            required
                            value={form.city}
                            onChange={handleChange}
                            placeholder="New York"
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                            style={{ fontSize: "0.875rem" }}
                          />
                        </div>
                        <div>
                          <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                            ZIP Code *
                          </label>
                          <input
                            name="zip"
                            required
                            value={form.zip}
                            onChange={handleChange}
                            placeholder="10001"
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                            style={{ fontSize: "0.875rem" }}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                          Delivery Notes (optional)
                        </label>
                        <textarea
                          name="notes"
                          value={form.notes}
                          onChange={handleChange}
                          placeholder="e.g., Leave at the door, no bell"
                          rows={2}
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent resize-none"
                          style={{ fontSize: "0.875rem" }}
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors"
                        style={{ fontWeight: 600 }}
                      >
                        Continue to Payment →
                      </button>
                    </motion.form>
                  )}

                  {step === "payment" && (
                    <motion.form
                      key="payment-form"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      onSubmit={handlePayment}
                      className="bg-white rounded-2xl shadow-sm p-6 space-y-4"
                    >
                      <div className="flex items-center gap-2 mb-5">
                        <CreditCard className="w-4 h-4 text-green-600" />
                        <h3 className="text-gray-800" style={{ fontWeight: 600 }}>
                          Payment Details
                        </h3>
                      </div>
                      <div className="flex gap-3 p-3 bg-blue-50 rounded-xl mb-2">
                        <span style={{ fontSize: "0.8rem" }} className="text-blue-600">
                          🔒 Your payment is secured with 256-bit SSL encryption.
                        </span>
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                          Name on Card *
                        </label>
                        <input
                          name="cardName"
                          required
                          value={form.cardName}
                          onChange={handleChange}
                          placeholder="Jane Doe"
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                          style={{ fontSize: "0.875rem" }}
                        />
                      </div>
                      <div>
                        <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                          Card Number *
                        </label>
                        <input
                          name="cardNumber"
                          required
                          value={form.cardNumber}
                          onChange={(e) => {
                            const raw = e.target.value.replace(/\D/g, "").slice(0, 16);
                            const formatted = raw.replace(/(.{4})/g, "$1 ").trim();
                            setForm((prev) => ({ ...prev, cardNumber: formatted }));
                          }}
                          placeholder="1234 5678 9012 3456"
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                          style={{ fontSize: "0.875rem" }}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                            Expiry Date *
                          </label>
                          <input
                            name="expiry"
                            required
                            value={form.expiry}
                            onChange={(e) => {
                              const raw = e.target.value.replace(/\D/g, "").slice(0, 4);
                              const formatted = raw.length > 2 ? raw.slice(0, 2) + "/" + raw.slice(2) : raw;
                              setForm((prev) => ({ ...prev, expiry: formatted }));
                            }}
                            placeholder="MM/YY"
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                            style={{ fontSize: "0.875rem" }}
                          />
                        </div>
                        <div>
                          <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>
                            CVV *
                          </label>
                          <input
                            name="cvv"
                            required
                            value={form.cvv}
                            onChange={(e) => {
                              const raw = e.target.value.replace(/\D/g, "").slice(0, 4);
                              setForm((prev) => ({ ...prev, cvv: raw }));
                            }}
                            placeholder="123"
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                            style={{ fontSize: "0.875rem" }}
                          />
                        </div>
                      </div>
                      <div className="flex gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => setStep("details")}
                          className="flex-1 py-3 border border-gray-200 text-gray-700 rounded-full hover:bg-gray-50 transition-colors"
                          style={{ fontWeight: 500 }}
                        >
                          ← Back
                        </button>
                        <button
                          type="submit"
                          className="flex-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors"
                          style={{ fontWeight: 600, flex: 2 }}
                        >
                          Pay ${total.toFixed(2)}
                        </button>
                      </div>
                    </motion.form>
                  )}
                </div>

                {/* Order Summary */}
                <div>
                  <div className="bg-white rounded-2xl shadow-sm p-5 sticky top-24">
                    <h3 className="text-gray-800 mb-4" style={{ fontWeight: 600 }}>
                      Order Summary
                    </h3>
                    <div className="space-y-3 mb-4">
                      {items.map((item) => (
                        <div key={item.product.id} className="flex items-center gap-3">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-gray-700 truncate" style={{ fontSize: "0.82rem", fontWeight: 600 }}>
                              {item.product.name}
                            </p>
                            <p className="text-gray-400" style={{ fontSize: "0.75rem" }}>
                              x{item.quantity}
                            </p>
                          </div>
                          <span className="text-gray-700" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="border-t border-gray-100 pt-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-500" style={{ fontSize: "0.85rem" }}>Subtotal</span>
                        <span className="text-gray-700" style={{ fontWeight: 600, fontSize: "0.85rem" }}>
                          ${totalPrice.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500" style={{ fontSize: "0.85rem" }}>Delivery</span>
                        <span
                          className={delivery === 0 ? "text-green-600" : "text-gray-700"}
                          style={{ fontWeight: 600, fontSize: "0.85rem" }}
                        >
                          {delivery === 0 ? "FREE" : `$${delivery.toFixed(2)}`}
                        </span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-gray-100">
                        <span className="text-gray-800" style={{ fontWeight: 700 }}>Total</span>
                        <span className="text-green-600" style={{ fontWeight: 700, fontSize: "1.05rem" }}>
                          ${total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-green-50 rounded-xl">
                      <p className="text-green-700" style={{ fontSize: "0.78rem" }}>
                        🌿 All orders come in eco-friendly, compostable packaging.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
