import { motion } from "motion/react";
import { Leaf, Heart, Users, Sprout } from "lucide-react";
import { Link } from "react-router";

const team = [
  { name: "Elena Rossi", role: "Head Chef & Co-founder", initial: "E", color: "bg-green-100 text-green-700" },
  { name: "Marcus Chen", role: "Nutritionist & Co-founder", initial: "M", color: "bg-orange-100 text-orange-700" },
  { name: "Sofia Navarro", role: "Farm Partnerships", initial: "S", color: "bg-purple-100 text-purple-700" },
];

const values = [
  { icon: Leaf, title: "Organic First", desc: "We only work with certified organic farms to bring you the cleanest ingredients possible.", color: "bg-green-100 text-green-600" },
  { icon: Heart, title: "Made With Love", desc: "Every salad is crafted by hand in our kitchen with attention to flavor, nutrition, and beauty.", color: "bg-red-100 text-red-600" },
  { icon: Users, title: "Community Driven", desc: "We partner with local farmers and donate 2% of profits to urban food access programs.", color: "bg-blue-100 text-blue-600" },
  { icon: Sprout, title: "Sustainability", desc: "Our packaging is 100% compostable. We aim for zero food waste through daily prep calculations.", color: "bg-emerald-100 text-emerald-600" },
];

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-gradient-to-br from-green-50 to-white py-16 md:py-24">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="inline-flex items-center gap-1.5 bg-green-100 text-green-700 px-3 py-1 rounded-full mb-4" style={{ fontSize: "0.8rem", fontWeight: 600 }}>
              <Leaf className="w-3 h-3" /> Our Story
            </span>
            <h1 className="text-gray-900 mb-5" style={{ fontSize: "clamp(2rem, 5vw, 3rem)", fontWeight: 800, lineHeight: 1.2 }}>
              Rooted in Nature,<br />Crafted with Purpose
            </h1>
            <p className="text-gray-500 max-w-2xl mx-auto" style={{ fontSize: "1.05rem", lineHeight: 1.8 }}>
              FreshBowl was born from a simple belief: eating healthy should be delicious, convenient, and accessible to everyone. We started in a small kitchen in 2021 and have grown into a beloved community staple.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-gray-900 mb-10" style={{ fontSize: "1.7rem", fontWeight: 700 }}>
            What We Stand For
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((val, i) => (
              <motion.div
                key={val.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-gray-50 rounded-2xl p-6"
              >
                <div className={`w-12 h-12 rounded-2xl ${val.color} flex items-center justify-center mb-4`}>
                  <val.icon className="w-6 h-6" />
                </div>
                <h3 className="text-gray-800 mb-2" style={{ fontSize: "0.95rem", fontWeight: 600 }}>
                  {val.title}
                </h3>
                <p className="text-gray-500" style={{ fontSize: "0.85rem", lineHeight: 1.6 }}>
                  {val.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-gray-900 mb-2" style={{ fontSize: "1.7rem", fontWeight: 700 }}>Meet the Team</h2>
          <p className="text-gray-500 mb-10" style={{ fontSize: "0.95rem" }}>The passionate people behind every bowl.</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {team.map((member) => (
              <div key={member.name} className="bg-white rounded-2xl p-6 shadow-sm">
                <div className={`w-16 h-16 rounded-full ${member.color} flex items-center justify-center mx-auto mb-4`} style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                  {member.initial}
                </div>
                <h3 className="text-gray-800" style={{ fontWeight: 600 }}>{member.name}</h3>
                <p className="text-gray-400 mt-1" style={{ fontSize: "0.8rem" }}>{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-white">
        <div className="max-w-xl mx-auto text-center px-4">
          <h2 className="text-gray-900 mb-3" style={{ fontSize: "1.6rem", fontWeight: 700 }}>
            Ready to eat fresh?
          </h2>
          <p className="text-gray-500 mb-6">
            Explore our menu and find your new favorite bowl.
          </p>
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 px-7 py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors shadow-sm"
            style={{ fontWeight: 600 }}
          >
            <Leaf className="w-4 h-4" /> Browse Menu
          </Link>
        </div>
      </section>
    </div>
  );
}
