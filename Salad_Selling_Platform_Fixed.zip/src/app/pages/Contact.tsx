import { useState } from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2 } from "lucide-react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-gray-50/40">
      {/* Header */}
      <div className="bg-gradient-to-br from-green-50 to-white py-14">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-gray-900 mb-3" style={{ fontSize: "clamp(1.8rem, 4vw, 2.5rem)", fontWeight: 800 }}>
            Get in Touch
          </h1>
          <p className="text-gray-500" style={{ fontSize: "1.05rem" }}>
            We'd love to hear from you. Reach out anytime!
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-5 gap-8">
          {/* Info */}
          <div className="md:col-span-2 space-y-5">
            {[
              { icon: Mail, label: "Email", value: "hello@freshbowl.com", color: "bg-blue-100 text-blue-600" },
              { icon: Phone, label: "Phone", value: "+1 (555) 234-5678", color: "bg-green-100 text-green-600" },
              { icon: MapPin, label: "Location", value: "42 Garden Lane, New York, NY 10001", color: "bg-orange-100 text-orange-600" },
              { icon: Clock, label: "Hours", value: "Mon–Sat: 8am – 8pm\nSun: 9am – 6pm", color: "bg-purple-100 text-purple-600" },
            ].map((item) => (
              <div key={item.label} className="flex gap-4 bg-white rounded-2xl p-4 shadow-sm">
                <div className={`w-10 h-10 rounded-xl ${item.color} flex items-center justify-center shrink-0`}>
                  <item.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-gray-400" style={{ fontSize: "0.75rem", fontWeight: 600 }}>
                    {item.label}
                  </p>
                  <p className="text-gray-700 whitespace-pre-line" style={{ fontSize: "0.875rem" }}>
                    {item.value}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Form */}
          <div className="md:col-span-3 bg-white rounded-2xl shadow-sm p-6">
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center h-full py-12 text-center"
              >
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-gray-800 mb-2" style={{ fontSize: "1.2rem", fontWeight: 700 }}>
                  Message Sent!
                </h3>
                <p className="text-gray-500" style={{ fontSize: "0.875rem" }}>
                  Thanks for reaching out. We'll get back to you within 24 hours.
                </p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="text-gray-800 mb-5" style={{ fontWeight: 600 }}>
                  Send us a Message
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>Name *</label>
                    <input
                      required
                      value={form.name}
                      onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                      placeholder="Jane Doe"
                      className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                      style={{ fontSize: "0.875rem" }}
                    />
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>Email *</label>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
                      placeholder="jane@example.com"
                      className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                      style={{ fontSize: "0.875rem" }}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>Subject *</label>
                  <input
                    required
                    value={form.subject}
                    onChange={(e) => setForm((p) => ({ ...p, subject: e.target.value }))}
                    placeholder="What's on your mind?"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                    style={{ fontSize: "0.875rem" }}
                  />
                </div>
                <div>
                  <label className="block text-gray-600 mb-1" style={{ fontSize: "0.8rem" }}>Message *</label>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm((p) => ({ ...p, message: e.target.value }))}
                    placeholder="Tell us how we can help..."
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent resize-none"
                    style={{ fontSize: "0.875rem" }}
                  />
                </div>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors"
                  style={{ fontWeight: 600 }}
                >
                  <Send className="w-4 h-4" /> Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
