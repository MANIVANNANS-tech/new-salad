
  # Salad Selling Platform

  This is a code bundle for Salad Selling Platform. The original project is available at https://www.figma.com/design/cS7gsxCO07UTpqUU5CRfZA/Salad-Selling-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  