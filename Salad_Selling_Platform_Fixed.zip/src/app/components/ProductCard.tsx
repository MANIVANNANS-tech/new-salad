import { useState } from "react";
import { Star, Plus, Check, Flame, Leaf, Zap } from "lucide-react";
import type { Product } from "../data/products";
import { useCart } from "../context/CartContext";
import { motion, AnimatePresence } from "motion/react";

const badgeColors: Record<string, string> = {
  Bestseller: "bg-orange-100 text-orange-700",
  Popular: "bg-purple-100 text-purple-700",
  "Chef's Pick": "bg-yellow-100 text-yellow-700",
  "Fan Favorite": "bg-blue-100 text-blue-700",
  Superfood: "bg-emerald-100 text-emerald-700",
  New: "bg-green-100 text-green-700",
  Seasonal: "bg-amber-100 text-amber-700",
  "Kids Fav": "bg-pink-100 text-pink-700",
  "High Protein": "bg-blue-100 text-blue-700",
  Premium: "bg-indigo-100 text-indigo-700",
  "Plant Power": "bg-emerald-100 text-emerald-700",
};

interface ProductCardProps {
  product: Product;
  audience?: "all" | "children" | "adult";
}

export function ProductCard({ product, audience = "all" }: ProductCardProps) {
  const { addToCart } = useCart();
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const isChildren = audience === "children";
  const isAdult = audience === "adult";

  // Protein bar fill %
  const maxProtein = isChildren ? 12 : isAdult ? 45 : 45;
  const proteinPct = Math.min(100, Math.round((product.protein / maxProtein) * 100));

  const proteinColor = isChildren
    ? "bg-pink-400"
    : product.protein >= 25
    ? "bg-blue-500"
    : product.protein >= 14
    ? "bg-green-500"
    : "bg-yellow-400";

  const proteinBg = isChildren ? "bg-pink-100" : "bg-gray-100";

  const btnClass = isChildren
    ? "bg-pink-500 hover:bg-pink-600 text-white"
    : isAdult
    ? "bg-blue-600 hover:bg-blue-700 text-white"
    : "bg-green-500 hover:bg-green-600 text-white";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.25 }}
      className={`bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow border flex flex-col ${
        isChildren ? "border-pink-100" : isAdult ? "border-blue-100" : "border-gray-100"
      }`}
    >
      {/* Image */}
      <div className="relative overflow-hidden h-48">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
        {product.badge && (
          <span className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-semibold ${badgeColors[product.badge] || "bg-gray-100 text-gray-700"}`}>
            {product.badge}
          </span>
        )}
        <div className="absolute top-3 right-3 flex flex-col gap-1 items-end">
          <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1">
            <Flame className="w-3 h-3 text-orange-400" />
            <span className="text-gray-700" style={{ fontSize: "0.72rem", fontWeight: 600 }}>
              {product.calories} kcal
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col">
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h3 className="text-gray-800" style={{ fontWeight: 600, fontSize: "0.95rem", lineHeight: 1.3 }}>
            {product.name}
          </h3>
          <span
            className={`shrink-0 ${isChildren ? "text-pink-600" : isAdult ? "text-blue-600" : "text-green-600"}`}
            style={{ fontWeight: 700, fontSize: "1rem" }}
          >
            ${product.price.toFixed(2)}
          </span>
        </div>

        <p className="text-gray-500 mb-3 flex-1" style={{ fontSize: "0.8rem", lineHeight: 1.5 }}>
          {product.description.length > 90
            ? product.description.slice(0, 90) + "…"
            : product.description}
        </p>

        {/* Protein bar */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1">
            <span className="flex items-center gap-1 text-gray-500" style={{ fontSize: "0.72rem" }}>
              <Zap className="w-3 h-3" /> Protein
            </span>
            <span style={{ fontSize: "0.72rem", fontWeight: 700 }}
              className={isChildren ? "text-pink-600" : isAdult ? "text-blue-600" : "text-gray-700"}>
              {product.protein}g
            </span>
          </div>
          <div className={`w-full h-2 rounded-full overflow-hidden ${proteinBg}`}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${proteinPct}%` }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className={`h-full rounded-full ${proteinColor}`}
            />
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {product.tags.slice(0, 2).map((tag) => (
            <span
              key={tag}
              className={`flex items-center gap-0.5 px-2 py-0.5 rounded-full ${
                isChildren ? "bg-pink-50 text-pink-600" : isAdult ? "bg-blue-50 text-blue-600" : "bg-green-50 text-green-700"
              }`}
              style={{ fontSize: "0.7rem" }}
            >
              <Leaf className="w-2.5 h-2.5" />
              {tag}
            </span>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-200 fill-gray-200"}`}
                />
              ))}
            </div>
            <span className="text-gray-400" style={{ fontSize: "0.75rem" }}>({product.reviews})</span>
          </div>

          <button
            onClick={handleAdd}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all duration-200 ${btnClass}`}
            style={{ fontSize: "0.8rem", fontWeight: 600 }}
          >
            <AnimatePresence mode="wait">
              {added ? (
                <motion.span key="check" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="flex items-center gap-1">
                  <Check className="w-3 h-3" /> Added!
                </motion.span>
              ) : (
                <motion.span key="add" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="flex items-center gap-1">
                  <Plus className="w-3 h-3" /> Add
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>
      </div>
    </motion.div>
  );
}
