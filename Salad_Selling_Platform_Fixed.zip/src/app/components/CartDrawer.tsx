import { X, ShoppingBag, Trash2, Plus, Minus, ArrowRight } from "lucide-react";
import { useCart } from "../context/CartContext";
import { motion, AnimatePresence } from "motion/react";
import { Link } from "react-router";

export function CartDrawer() {
  const { items, isCartOpen, setIsCartOpen, removeFromCart, updateQuantity, totalPrice, totalItems } = useCart();

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-green-600" />
                <h2 className="text-gray-800" style={{ fontSize: "1.1rem", fontWeight: 600 }}>
                  Your Cart
                </h2>
                {totalItems > 0 && (
                  <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full" style={{ fontSize: "0.75rem", fontWeight: 600 }}>
                    {totalItems} item{totalItems !== 1 ? "s" : ""}
                  </span>
                )}
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-700 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              <AnimatePresence mode="popLayout">
                {items.length === 0 ? (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center h-full text-center py-16"
                  >
                    <div className="w-20 h-20 rounded-full bg-green-50 flex items-center justify-center mb-4">
                      <ShoppingBag className="w-9 h-9 text-green-300" />
                    </div>
                    <h3 className="text-gray-500 mb-1">Your cart is empty</h3>
                    <p className="text-gray-400" style={{ fontSize: "0.875rem" }}>
                      Add some fresh salads to get started!
                    </p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="mt-6 px-5 py-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors"
                      style={{ fontSize: "0.875rem" }}
                    >
                      Browse Menu
                    </button>
                  </motion.div>
                ) : (
                  items.map((item) => (
                    <motion.div
                      key={item.product.id}
                      layout
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20, height: 0, marginBottom: 0 }}
                      transition={{ duration: 0.2 }}
                      className="flex gap-3 mb-4 pb-4 border-b border-gray-50 last:border-0"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-gray-800 truncate" style={{ fontSize: "0.875rem", fontWeight: 600 }}>
                          {item.product.name}
                        </h4>
                        <p className="text-green-600 mt-0.5" style={{ fontSize: "0.875rem", fontWeight: 600 }}>
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-1 bg-gray-100 rounded-full">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                              className="w-6 h-6 flex items-center justify-center rounded-full hover:bg-gray-200 transition-colors text-gray-600"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-6 text-center" style={{ fontSize: "0.8rem", fontWeight: 600 }}>
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                              className="w-6 h-6 flex items-center justify-center rounded-full hover:bg-gray-200 transition-colors text-gray-600"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="w-6 h-6 flex items-center justify-center rounded-full hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t border-gray-100 px-6 py-5 bg-gray-50/80">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-gray-500" style={{ fontSize: "0.875rem" }}>Subtotal</span>
                  <span className="text-gray-800" style={{ fontWeight: 600 }}>${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-gray-500" style={{ fontSize: "0.875rem" }}>Delivery</span>
                  <span className="text-green-600" style={{ fontSize: "0.875rem", fontWeight: 600 }}>
                    {totalPrice >= 30 ? "FREE" : "$3.99"}
                  </span>
                </div>
                <div className="flex items-center justify-between mb-5">
                  <span className="text-gray-800" style={{ fontWeight: 600 }}>Total</span>
                  <span className="text-green-700" style={{ fontSize: "1.1rem", fontWeight: 700 }}>
                    ${(totalPrice >= 30 ? totalPrice : totalPrice + 3.99).toFixed(2)}
                  </span>
                </div>
                {totalPrice < 30 && (
                  <p className="text-center text-orange-500 mb-3" style={{ fontSize: "0.8rem" }}>
                    Add ${(30 - totalPrice).toFixed(2)} more for free delivery!
                  </p>
                )}
                <Link
                  to="/checkout"
                  onClick={() => setIsCartOpen(false)}
                  className="flex items-center justify-center gap-2 w-full py-3 bg-green-500 hover:bg-green-600 text-white rounded-full transition-colors shadow-sm"
                  style={{ fontWeight: 600 }}
                >
                  Checkout <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
